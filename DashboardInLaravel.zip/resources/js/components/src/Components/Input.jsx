import React from "react";

const Input = props => {
  return (
    <div>
      <input placeholder="check" />
    </div>
  );
};

export default Input;
